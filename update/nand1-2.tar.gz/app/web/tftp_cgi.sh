echo "tftp cgi..."
cd cgi-bin

tftp -r gpio.cgi 192.168.1.200 -g
tftp -r mainFrame.cgi 192.168.1.200 -g 
tftp -r net.cgi 192.168.1.200 -g
tftp -r top.cgi 192.168.1.200 -g
tftp -r factory.cgi 192.168.1.200 -g
tftp -r host.cgi 192.168.1.200 -g
tftp -r server.cgi 192.168.1.200 -g
tftp -r upgrade.cgi 192.168.1.200 -g
